import json
import base64
import boto3

u2net_endpoint_name = "serverless-endpoint-u2net"
result_page_script = open("result_page.html", "r").read()


def invoke_endpoint(filedata):
    sagemaker_runtime = boto3.client("sagemaker-runtime")

    print("Invoking U2Net Model....")
    u2net_response = sagemaker_runtime.invoke_endpoint(
        EndpointName=u2net_endpoint_name,
        ContentType="image/jpeg",
        Body=filedata,
    )

    output = json.loads(u2net_response["Body"].read())["response"]
    return output


def lambda_handler(event, context):
    print(event)
    if event["path"] == '/':
        response = {
            "statusCode": 200,
            "body": open("index.html", "r").read(),
            "headers": {
                'Content-Type': 'text/html',
            }
        }
        return response


    file_content = base64.b64decode(event['content'])
    
    filename_start_index = file_content.index(b'filename="')+len(b'filename="')
    filename_end_index = file_content.index(b'Content-Type')-3
    filename = file_content[filename_start_index:filename_end_index].decode("utf-8")
    
    
    data_start_index = file_content.index(b'image/jpeg')+14
    data_end_index = file_content[file_content.index(b'------WebKitFormBoundary')+20:].index(b'------WebKitFormBoundary')+18
    file_data = file_content[data_start_index:data_end_index]
    
    print("filename:::", filename)
    output = invoke_endpoint(file_data)
    
    file_b64 = base64.b64encode(file_data)
    result_b64 = output["img"]
    file_src = "data:image/jpg;base64,"+file_b64.decode("utf-8")
    result_src = "data:image/png;base64,"+result_b64
    
    response = {
        "statusCode": 200,
        "body": result_page_script.format(file_src, result_src),
        "headers": {
            'Content-Type': 'text/html',
        },
        "isBase64Encoded":  False
    }
    return response
